/* L�gico_ex11: */

CREATE TABLE paciente (
    id integer PRIMARY KEY,
    nome varchar(50),
    endereco varchar(100),
    telefone varchar(50),
    data_nascimento date,
    _primeira_consulta date,
    e_mail varchar(100),
    tipo varchar(50),
    plano_saude varchar(50)
);

CREATE TABLE plano_de_saude (
    id integer PRIMARY KEY,
    nome_ varchar(50),
    limite_consultas_mes integer,
    fk_paciente_id integer
);

CREATE TABLE consulta (
    id integer PRIMARY KEY,
    tipo_ varchar(50),
    consultorio varchar(50),
    paciente varchar(50),
    data date,
    hora time,
    fk_paciente_id integer
);

CREATE TABLE consultorio (
    id integer PRIMARY KEY,
    localizacao_ varchar(100),
    dias_atendimento text,
    horario_atendimento time,
    fk_consulta_id integer
);
 
ALTER TABLE plano_de_saude ADD CONSTRAINT FK_plano_de_saude_2
    FOREIGN KEY (fk_paciente_id)
    REFERENCES paciente (id)
    ON DELETE SET NULL;
 
ALTER TABLE consulta ADD CONSTRAINT FK_consulta_2
    FOREIGN KEY (fk_paciente_id)
    REFERENCES paciente (id)
    ON DELETE RESTRICT;
 
ALTER TABLE consultorio ADD CONSTRAINT FK_consultorio_2
    FOREIGN KEY (fk_consulta_id)
    REFERENCES consulta (id)
    ON DELETE RESTRICT;