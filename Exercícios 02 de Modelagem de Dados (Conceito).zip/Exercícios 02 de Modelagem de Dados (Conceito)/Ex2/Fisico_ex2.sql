/* L�gico_ex2: */

CREATE TABLE ligacao (
    id integer PRIMARY KEY,
    data_ligacao date,
    hora_ligacao time,
    minutos_gasto integer,
    numero_pulso integer,
    telefone_discado varchar(50),
    fk_agenda_id integer
);

CREATE TABLE agenda (
    id integer PRIMARY KEY,
    numero_telefone varchar(50),
    nome_contato varchar(100)
);
 
ALTER TABLE ligacao ADD CONSTRAINT FK_ligacao_2
    FOREIGN KEY (fk_agenda_id)
    REFERENCES agenda (id)
    ON DELETE SET NULL;