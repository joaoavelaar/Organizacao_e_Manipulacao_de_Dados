/* L�gico_ex1: */

CREATE TABLE tarefa (
    id integer PRIMARY KEY,
    numero_prioridade float,
    data_limite_execucao date,
    percentual_concluido float,
    detalhamento_tarefa_ varchar(100),
    data_conclusao date
);

CREATE TABLE item_execucao (
    id integer PRIMARY KEY,
    percentual float,
    descricao_execucao varchar(100),
    data_execucao date,
    fk_tarefa_id integer
);
 
ALTER TABLE item_execucao ADD CONSTRAINT FK_item_execucao_2
    FOREIGN KEY (fk_tarefa_id)
    REFERENCES tarefa (id)
    ON DELETE RESTRICT;