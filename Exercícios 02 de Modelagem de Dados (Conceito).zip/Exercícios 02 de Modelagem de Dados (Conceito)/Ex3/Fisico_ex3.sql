/* L�gico_ex3: */

CREATE TABLE teste (
    id integer PRIMARY KEY,
    data_geracao date,
    n_questoes integer,
    disciplina varchar(50)
);

CREATE TABLE questao (
    id integer PRIMARY KEY,
    bimestre integer,
    materia varchar(50),
    gabarito varchar(50),
    fk_materia_id integer
);

CREATE TABLE disciplina (
    id integer PRIMARY KEY,
    nome varchar(50)
);

CREATE TABLE materia (
    id integer PRIMARY KEY,
    nome varchar(50),
    serie integer,
    fk_disciplina_id integer
);

CREATE TABLE contem (
    fk_questao_id integer,
    fk_teste_id integer
);
 
ALTER TABLE questao ADD CONSTRAINT FK_questao_2
    FOREIGN KEY (fk_materia_id)
    REFERENCES materia (id)
    ON DELETE RESTRICT;
 
ALTER TABLE materia ADD CONSTRAINT FK_materia_2
    FOREIGN KEY (fk_disciplina_id)
    REFERENCES disciplina (id)
    ON DELETE RESTRICT;
 
ALTER TABLE contem ADD CONSTRAINT FK_contem_1
    FOREIGN KEY (fk_questao_id)
    REFERENCES questao (id)
    ON DELETE RESTRICT;
 
ALTER TABLE contem ADD CONSTRAINT FK_contem_2
    FOREIGN KEY (fk_teste_id)
    REFERENCES teste (id)
    ON DELETE SET NULL;