/* L�gico_ex5: */

CREATE TABLE matricula (
    id integer PRIMARY KEY,
    data_matricula date,
    valor_pago decimal
);

CREATE TABLE aluno (
    id integer PRIMARY KEY,
    nome varchar(200),
    rg varchar(50),
    cpf varchar(50),
    data_nascimento date,
    endereco varchar(200),
    telefone varchar(50),
    fk_matricula_id integer
);

CREATE TABLE curso (
    id integer PRIMARY KEY,
    data_inicio date,
    data_termino date,
    horario_inicio time,
    horario_termino time,
    nome_professor varchar(200),
    telefone_professor varchar(50),
    valor_hora_professor decimal,
    carga_horaria integer,
    conteudo_programatico text,
    valor_curso decimal
);

CREATE TABLE contem (
    fk_matricula_id integer,
    fk_curso_id integer
);
 
ALTER TABLE aluno ADD CONSTRAINT FK_aluno_2
    FOREIGN KEY (fk_matricula_id)
    REFERENCES matricula (id)
    ON DELETE RESTRICT;
 
ALTER TABLE contem ADD CONSTRAINT FK_contem_1
    FOREIGN KEY (fk_matricula_id)
    REFERENCES matricula (id)
    ON DELETE RESTRICT;
 
ALTER TABLE contem ADD CONSTRAINT FK_contem_2
    FOREIGN KEY (fk_curso_id)
    REFERENCES curso (id)
    ON DELETE RESTRICT;