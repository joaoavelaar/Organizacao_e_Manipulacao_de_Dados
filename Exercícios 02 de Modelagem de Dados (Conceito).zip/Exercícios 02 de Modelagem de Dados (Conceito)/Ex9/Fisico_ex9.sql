/* L�gico_ex9: */

CREATE TABLE revista (
    id integer PRIMARY KEY,
    tipo varchar(50),
    n_edicao integer,
    ano varchar(4),
    fk_caixa_id integer
);

CREATE TABLE caixa (
    id integer PRIMARY KEY,
    cor varchar(50),
    etiqueta varchar(50),
    numero integer
);

CREATE TABLE emprestimo (
    id integer PRIMARY KEY,
    data_emprestimo date,
    data_devolucao date,
    fk_revista_id integer,
    fk_amigo_id integer
);

CREATE TABLE amigo (
    id integer PRIMARY KEY,
    nome varchar(50),
    nome_mae varchar(50),
    telefone varchar(50),
    origem varchar(50)
);
 
ALTER TABLE revista ADD CONSTRAINT FK_revista_2
    FOREIGN KEY (fk_caixa_id)
    REFERENCES caixa (id)
    ON DELETE RESTRICT;
 
ALTER TABLE emprestimo ADD CONSTRAINT FK_emprestimo_2
    FOREIGN KEY (fk_revista_id)
    REFERENCES revista (id)
    ON DELETE RESTRICT;
 
ALTER TABLE emprestimo ADD CONSTRAINT FK_emprestimo_3
    FOREIGN KEY (fk_amigo_id)
    REFERENCES amigo (id)
    ON DELETE RESTRICT;