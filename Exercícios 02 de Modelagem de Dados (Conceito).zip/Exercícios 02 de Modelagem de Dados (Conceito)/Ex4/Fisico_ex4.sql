/* L�gico_ex4: */

CREATE TABLE aluguel (
    id integer PRIMARY KEY,
    nome_cliente_ varchar(50),
    telefone_cliente varchar(50),
    tema varchar(50),
    data date,
    hora_inicio time,
    hora_termino time,
    valor decimal
);

CREATE TABLE tema (
    id integer PRIMARY KEY,
    lista_itens text,
    valor_aluguel decimal,
    cor_toalha_mesa varchar(50)
);

CREATE TABLE contem (
    fk_tema_id integer,
    fk_aluguel_id integer
);
 
ALTER TABLE contem ADD CONSTRAINT FK_contem_1
    FOREIGN KEY (fk_tema_id)
    REFERENCES tema (id)
    ON DELETE RESTRICT;
 
ALTER TABLE contem ADD CONSTRAINT FK_contem_2
    FOREIGN KEY (fk_aluguel_id)
    REFERENCES aluguel (id)
    ON DELETE SET NULL;