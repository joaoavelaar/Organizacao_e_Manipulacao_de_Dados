/* L�gico_ex12: */

CREATE TABLE apostador (
    id integer PRIMARY KEY,
    nome varchar(50)
);

CREATE TABLE concurso (
    id integer PRIMARY KEY,
    numero_sorteado varchar(50),
    tipo_jogo varchar(50),
    data_sorteio date,
    fk_resultado_cartao_id integer
);

CREATE TABLE resultado_cartao (
    id integer PRIMARY KEY,
    cartao varchar(50),
    concurso varchar(50),
    numero_acertado varchar(50),
    valor_premio float,
    numero varchar(50),
    tipo_jogo varchar(50),
    data date,
    fk_apostador_id integer
);
 
ALTER TABLE concurso ADD CONSTRAINT FK_concurso_2
    FOREIGN KEY (fk_resultado_cartao_id)
    REFERENCES resultado_cartao (id)
    ON DELETE RESTRICT;
 
ALTER TABLE resultado_cartao ADD CONSTRAINT FK_resultado_cartao_2
    FOREIGN KEY (fk_apostador_id)
    REFERENCES apostador (id);