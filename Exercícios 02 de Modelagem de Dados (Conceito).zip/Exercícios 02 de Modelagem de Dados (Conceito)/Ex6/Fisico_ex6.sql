/* L�gico_ex6: */

CREATE TABLE anunciante (
    id integer PRIMARY KEY,
    nome varchar(50),
    contato varchar(50),
    telefones varchar(50),
    observacao_telefone varchar(100)
);

CREATE TABLE anuncio (
    id integer PRIMARY KEY,
    tipo varchar(50),
    conteudo varchar(50),
    data_insecao date,
    secao varchar(50),
    preco varchar(50)
);

CREATE TABLE assinante (
    id integer PRIMARY KEY,
    nome varchar(50),
    email varchar(100),
    secoes_interesse varchar(50)
);

CREATE TABLE publica (
    fk_anunciante_id integer,
    fk_anuncio_id integer
);

CREATE TABLE recebe (
    fk_assinante_id integer,
    fk_anuncio_id integer
);
 
ALTER TABLE publica ADD CONSTRAINT FK_publica_1
    FOREIGN KEY (fk_anunciante_id)
    REFERENCES anunciante (id)
    ON DELETE RESTRICT;
 
ALTER TABLE publica ADD CONSTRAINT FK_publica_2
    FOREIGN KEY (fk_anuncio_id)
    REFERENCES anuncio (id)
    ON DELETE RESTRICT;
 
ALTER TABLE recebe ADD CONSTRAINT FK_recebe_1
    FOREIGN KEY (fk_assinante_id)
    REFERENCES assinante (id)
    ON DELETE RESTRICT;
 
ALTER TABLE recebe ADD CONSTRAINT FK_recebe_2
    FOREIGN KEY (fk_anuncio_id)
    REFERENCES anuncio (id)
    ON DELETE RESTRICT;