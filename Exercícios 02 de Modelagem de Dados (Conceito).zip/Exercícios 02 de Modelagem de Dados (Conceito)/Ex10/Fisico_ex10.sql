/* L�gico_ex10: */

CREATE TABLE apartamento (
    id integer PRIMARY KEY,
    numero integer,
    n_quarto integer,
    tipo_ocupacao varchar(50),
    fk_proprietario_id integer,
    fk_condominio_id integer
);

CREATE TABLE proprietario (
    id integer PRIMARY KEY,
    nome varchar(50),
    telefone varchar(50)
);

CREATE TABLE despesa (
    id integer PRIMARY KEY,
    valor decimal,
    referencia varchar(50),
    fator_parcelamento integer,
    fk_apartamento_id integer
);

CREATE TABLE condominio (
    id integer PRIMARY KEY,
    data_pagamento date,
    valor decimal
);
 
ALTER TABLE apartamento ADD CONSTRAINT FK_apartamento_2
    FOREIGN KEY (fk_proprietario_id)
    REFERENCES proprietario (id)
    ON DELETE RESTRICT;
 
ALTER TABLE apartamento ADD CONSTRAINT FK_apartamento_3
    FOREIGN KEY (fk_condominio_id)
    REFERENCES condominio (id)
    ON DELETE RESTRICT;
 
ALTER TABLE despesa ADD CONSTRAINT FK_despesa_2
    FOREIGN KEY (fk_apartamento_id)
    REFERENCES apartamento (id)
    ON DELETE RESTRICT;