/* L�gico_ex7: */

CREATE TABLE jogador (
    id integer PRIMARY KEY,
    nome varchar(50),
    pontuacao decimal
);

CREATE TABLE frase (
    id integer PRIMARY KEY,
    conteudo varchar(50),
    tema varchar(50),
    status varchar(50)
);

CREATE TABLE rodada (
    id integer PRIMARY KEY,
    n_palavras varchar(100),
    frase text,
    letras_erradas text,
    fk_boneco_id integer
);

CREATE TABLE boneco (
    id integer PRIMARY KEY,
    numero_peca_revelada integer
);

CREATE TABLE joga (
    fk_jogador_id integer,
    fk_rodada_id integer
);

CREATE TABLE contem (
    fk_rodada_id integer,
    fk_frase_id integer
);
 
ALTER TABLE rodada ADD CONSTRAINT FK_rodada_2
    FOREIGN KEY (fk_boneco_id)
    REFERENCES boneco (id)
    ON DELETE RESTRICT;
 
ALTER TABLE joga ADD CONSTRAINT FK_joga_1
    FOREIGN KEY (fk_jogador_id)
    REFERENCES jogador (id)
    ON DELETE RESTRICT;
 
ALTER TABLE joga ADD CONSTRAINT FK_joga_2
    FOREIGN KEY (fk_rodada_id)
    REFERENCES rodada (id)
    ON DELETE RESTRICT;
 
ALTER TABLE contem ADD CONSTRAINT FK_contem_1
    FOREIGN KEY (fk_rodada_id)
    REFERENCES rodada (id)
    ON DELETE RESTRICT;
 
ALTER TABLE contem ADD CONSTRAINT FK_contem_2
    FOREIGN KEY (fk_frase_id)
    REFERENCES frase (id)
    ON DELETE RESTRICT;